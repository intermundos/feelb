<template>

    <button class="btn btn-circle btn-outline btn-sm"
            @click="$router.back()"
    >
        <svg xmlns="http://www.w3.org/2000/svg" width="23" height="23" viewBox="0 0 24 24">
            <path fill="currentColor" d="M21 11H6.83l3.58-3.59L9 6l-6 6l6 6l1.41-1.42L6.83 13H21v-2Z"/>
        </svg>
    </button>

</template>
