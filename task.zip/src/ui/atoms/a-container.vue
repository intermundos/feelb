<style scoped lang="scss">

</style>

<template>

    <div class="container">
        <slot/>
    </div>

</template>

<script setup lang="ts">

</script>
