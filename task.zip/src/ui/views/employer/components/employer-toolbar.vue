<style scoped lang="scss">

</style>

<template>

    <div class="flex gap-3">
        <employer-add-employee-modal/>
    </div>

</template>

<script setup lang="ts">


</script>
