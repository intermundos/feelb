export default {
    'lj8tr1jjr96hn44xlo8': {
        id: 'lj8tr1jjr96hn44xlo8',
        firstName: 'John',
        lastName: 'Test',
        title: 'Test',
        email: 'ganderon@gmail.com',
        timeRecords: [
            {
                id: 'lj8qjoz3f965pubek6w',
                isCompleted: true,
                start: {
                    hour: 0,
                    minutes: 0,
                    date: 1687628119583,
                },
                end: {
                    hour: 1,
                    minutes: 0,
                    date: 1687658119583,
                },
            },
        ],
    },
}
