> run npm install
> open localhost:8888
